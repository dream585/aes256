# Dependencies: PyCrypto -> `pip install pycrypto`

from base64 import b64decode, b64encode
from Crypto.Cipher import AES

CIPHER_KEY = "0123456789abcdef0123456789abcdef"
IV = b"1234567890ABCDEF"
PADDING_CHAR = b"\034"


def encrypt(text):
    aes = AES.new(CIPHER_KEY, AES.MODE_CBC, IV)
    padded = text + PADDING_CHAR * (16 - len(text) % 16)
    encrypted = aes.encrypt(padded)
    return b64encode(encrypted)


def decrypt(data):
    aes = AES.new(CIPHER_KEY, AES.MODE_CBC, IV)
    encrypted = b64decode(data)
    padded = aes.decrypt(encrypted)
    return padded.rstrip(PADDING_CHAR)


message = "this information is confidential, for your eyes only"
print("secret message: {}".format(message))
encrypted_message = encrypt(message)
print("    encrypted > {}".format(encrypted_message))
decrypted_message = decrypt(encrypted_message)
print("    decrypted > {}".format(decrypted_message))
if message == decrypted_message:
    print("SUCCESS")
else:
    print("FAILED")