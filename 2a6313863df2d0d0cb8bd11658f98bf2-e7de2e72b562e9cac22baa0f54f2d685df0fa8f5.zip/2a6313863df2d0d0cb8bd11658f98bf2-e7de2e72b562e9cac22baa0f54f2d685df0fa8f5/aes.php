<?php
define('CIPHER_KEY', "0123456789abcdef0123456789abcdef");
define('IV', "1234567890ABCDEF");
define('PADDING_CHAR', "\034");

function encrypt($text)
{
    $padded = $text . str_repeat(PADDING_CHAR, (16 - strlen($text) % 16));
    return openssl_encrypt($padded, "AES-256-CBC", CIPHER_KEY, OPENSSL_ZERO_PADDING, IV);
}

function decrypt($data)
{
    $padded = openssl_decrypt($data, "AES-256-CBC", CIPHER_KEY, OPENSSL_ZERO_PADDING, IV);
    return rtrim($padded, PADDING_CHAR);
}


$message = "this information is confidential, for your eyes only";
echo "secret message: " . $message . "\n";
$encrypted_message = encrypt($message);
echo "    encrypted > " . $encrypted_message . "\n";
$decrypted_message = decrypt($encrypted_message);
echo "    decrypted > " . $decrypted_message . "\n";
echo $message === $decrypted_message ? "SUCCESS" : "FAILED" . "\n";
?>