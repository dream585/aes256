# Informations

cipher key: `0123456789abcdef0123456789abcdef`  
IV: `0123456789ABCDEF`  
padding character: `fs` (ASCII=34 -> `FILE SEPARATOR`)

# Expected output

```
secret message: this information is confidential, for your eyes only
    encrypted > K7aToyGnmyxFF+GHzMOsArYMibOqtWn3J9DxJGN2CczFIwc12/dAty4eV5tRtvPeLEC2cSiRtrtGBHuET8buSQ==
    decrypted > this information is confidential, for your eyes only
SUCCESS
```